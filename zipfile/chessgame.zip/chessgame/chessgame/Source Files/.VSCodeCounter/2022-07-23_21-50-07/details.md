# Details

Date : 2022-07-23 21:50:07

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 35 files,  2857 codes, 1221 comments, 586 blanks, all 4664 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/details.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/details.md) | Markdown | 31 | 0 | 6 | 37 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/diff-details.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/diff-details.md) | Markdown | 9 | 0 | 6 | 15 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/diff.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/diff.md) | Markdown | 12 | 0 | 7 | 19 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/results.json](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/results.json) | JSON | 1 | 0 | 0 | 1 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/results.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/results.md) | Markdown | 24 | 0 | 7 | 31 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/details.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/details.md) | Markdown | 39 | 0 | 6 | 45 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/diff-details.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/diff-details.md) | Markdown | 17 | 0 | 6 | 23 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/diff.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/diff.md) | Markdown | 18 | 0 | 7 | 25 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/results.json](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/results.json) | JSON | 1 | 0 | 0 | 1 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/results.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/results.md) | Markdown | 29 | 0 | 7 | 36 |
| [Source Files/SDL_Handler.cpp](/Source%20Files/SDL_Handler.cpp) | C++ | 639 | 65 | 130 | 834 |
| [Source Files/SDL_Handler.h](/Source%20Files/SDL_Handler.h) | C++ | 63 | 175 | 34 | 272 |
| [Source Files/chess/board/board.cpp](/Source%20Files/chess/board/board.cpp) | C++ | 262 | 21 | 58 | 341 |
| [Source Files/chess/board/board.h](/Source%20Files/chess/board/board.h) | C++ | 29 | 137 | 22 | 188 |
| [Source Files/chess/board/stack.cpp](/Source%20Files/chess/board/stack.cpp) | C++ | 101 | 0 | 17 | 118 |
| [Source Files/chess/board/stack.h](/Source%20Files/chess/board/stack.h) | C++ | 31 | 64 | 10 | 105 |
| [Source Files/chess/game.cpp](/Source%20Files/chess/game.cpp) | C++ | 160 | 13 | 30 | 203 |
| [Source Files/chess/game.h](/Source%20Files/chess/game.h) | C++ | 29 | 115 | 23 | 167 |
| [Source Files/chess/gamepieces/linkedlist/Llist.cpp](/Source%20Files/chess/gamepieces/linkedlist/Llist.cpp) | C++ | 88 | 0 | 21 | 109 |
| [Source Files/chess/gamepieces/linkedlist/Llist.h](/Source%20Files/chess/gamepieces/linkedlist/Llist.h) | C++ | 31 | 82 | 17 | 130 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.cpp](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.cpp) | C++ | 145 | 10 | 8 | 163 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.h](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.h) | C++ | 15 | 50 | 8 | 73 |
| [Source Files/chess/gamepieces/pieces/king/king.cpp](/Source%20Files/chess/gamepieces/pieces/king/king.cpp) | C++ | 232 | 29 | 34 | 295 |
| [Source Files/chess/gamepieces/pieces/king/king.h](/Source%20Files/chess/gamepieces/pieces/king/king.h) | C++ | 17 | 69 | 9 | 95 |
| [Source Files/chess/gamepieces/pieces/knight/knight.cpp](/Source%20Files/chess/gamepieces/pieces/knight/knight.cpp) | C++ | 132 | 18 | 7 | 157 |
| [Source Files/chess/gamepieces/pieces/knight/knight.h](/Source%20Files/chess/gamepieces/pieces/knight/knight.h) | C++ | 15 | 50 | 8 | 73 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.cpp](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.cpp) | C++ | 105 | 14 | 9 | 128 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.h](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.h) | C++ | 15 | 50 | 8 | 73 |
| [Source Files/chess/gamepieces/pieces/piece.cpp](/Source%20Files/chess/gamepieces/pieces/piece.cpp) | C++ | 53 | 0 | 12 | 65 |
| [Source Files/chess/gamepieces/pieces/piece.h](/Source%20Files/chess/gamepieces/pieces/piece.h) | C++ | 35 | 140 | 20 | 195 |
| [Source Files/chess/gamepieces/pieces/queen/queen.cpp](/Source%20Files/chess/gamepieces/pieces/queen/queen.cpp) | C++ | 268 | 10 | 16 | 294 |
| [Source Files/chess/gamepieces/pieces/queen/queen.h](/Source%20Files/chess/gamepieces/pieces/queen/queen.h) | C++ | 15 | 50 | 7 | 72 |
| [Source Files/chess/gamepieces/pieces/rook/rook.cpp](/Source%20Files/chess/gamepieces/pieces/rook/rook.cpp) | C++ | 145 | 2 | 12 | 159 |
| [Source Files/chess/gamepieces/pieces/rook/rook.h](/Source%20Files/chess/gamepieces/pieces/rook/rook.h) | C++ | 15 | 50 | 8 | 73 |
| [Source Files/main.cpp](/Source%20Files/main.cpp) | C++ | 36 | 7 | 6 | 49 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)