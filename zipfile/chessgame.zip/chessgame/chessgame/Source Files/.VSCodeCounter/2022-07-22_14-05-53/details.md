# Details

Date : 2022-07-22 14:05:53

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files\\chess

Total : 22 files,  1495 codes, 861 comments, 344 blanks, all 2700 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Source Files/chess/board/board.cpp](/Source%20Files/chess/board/board.cpp) | C++ | 208 | 21 | 45 | 274 |
| [Source Files/chess/board/board.h](/Source%20Files/chess/board/board.h) | C++ | 27 | 123 | 21 | 171 |
| [Source Files/chess/board/stack.cpp](/Source%20Files/chess/board/stack.cpp) | C++ | 92 | 0 | 17 | 109 |
| [Source Files/chess/board/stack.h](/Source%20Files/chess/board/stack.h) | C++ | 29 | 64 | 10 | 103 |
| [Source Files/chess/game.cpp](/Source%20Files/chess/game.cpp) | C++ | 139 | 12 | 32 | 183 |
| [Source Files/chess/game.h](/Source%20Files/chess/game.h) | C++ | 31 | 37 | 24 | 92 |
| [Source Files/chess/gamepieces/linkedlist/Llist.cpp](/Source%20Files/chess/gamepieces/linkedlist/Llist.cpp) | C++ | 77 | 0 | 21 | 98 |
| [Source Files/chess/gamepieces/linkedlist/Llist.h](/Source%20Files/chess/gamepieces/linkedlist/Llist.h) | C++ | 27 | 82 | 17 | 126 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.cpp](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.cpp) | C++ | 97 | 10 | 8 | 115 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.h](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.h) | C++ | 14 | 50 | 8 | 72 |
| [Source Files/chess/gamepieces/pieces/king/king.cpp](/Source%20Files/chess/gamepieces/pieces/king/king.cpp) | C++ | 173 | 26 | 31 | 230 |
| [Source Files/chess/gamepieces/pieces/king/king.h](/Source%20Files/chess/gamepieces/pieces/king/king.h) | C++ | 15 | 60 | 8 | 83 |
| [Source Files/chess/gamepieces/pieces/knight/knight.cpp](/Source%20Files/chess/gamepieces/pieces/knight/knight.cpp) | C++ | 96 | 18 | 7 | 121 |
| [Source Files/chess/gamepieces/pieces/knight/knight.h](/Source%20Files/chess/gamepieces/pieces/knight/knight.h) | C++ | 14 | 50 | 8 | 72 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.cpp](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.cpp) | C++ | 69 | 14 | 9 | 92 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.h](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.h) | C++ | 14 | 50 | 8 | 72 |
| [Source Files/chess/gamepieces/pieces/piece.cpp](/Source%20Files/chess/gamepieces/pieces/piece.cpp) | C++ | 44 | 0 | 11 | 55 |
| [Source Files/chess/gamepieces/pieces/piece.h](/Source%20Files/chess/gamepieces/pieces/piece.h) | C++ | 27 | 132 | 19 | 178 |
| [Source Files/chess/gamepieces/pieces/queen/queen.cpp](/Source%20Files/chess/gamepieces/pieces/queen/queen.cpp) | C++ | 177 | 10 | 16 | 203 |
| [Source Files/chess/gamepieces/pieces/queen/queen.h](/Source%20Files/chess/gamepieces/pieces/queen/queen.h) | C++ | 14 | 50 | 7 | 71 |
| [Source Files/chess/gamepieces/pieces/rook/rook.cpp](/Source%20Files/chess/gamepieces/pieces/rook/rook.cpp) | C++ | 97 | 2 | 9 | 108 |
| [Source Files/chess/gamepieces/pieces/rook/rook.h](/Source%20Files/chess/gamepieces/pieces/rook/rook.h) | C++ | 14 | 50 | 8 | 72 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)