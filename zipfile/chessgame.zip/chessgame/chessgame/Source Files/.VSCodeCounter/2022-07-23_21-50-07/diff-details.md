# Diff Details

Date : 2022-07-23 21:50:07

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 30 files,  826 codes, 287 comments, 94 blanks, all 1207 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/details.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/details.md) | Markdown | 39 | 0 | 6 | 45 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/diff-details.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/diff-details.md) | Markdown | 17 | 0 | 6 | 23 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/diff.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/diff.md) | Markdown | 18 | 0 | 7 | 25 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/results.json](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/results.json) | JSON | 1 | 0 | 0 | 1 |
| [Source Files/.VSCodeCounter/2022-07-22_15-03-37/results.md](/Source%20Files/.VSCodeCounter/2022-07-22_15-03-37/results.md) | Markdown | 29 | 0 | 7 | 36 |
| [Source Files/SDL_Handler.cpp](/Source%20Files/SDL_Handler.cpp) | C++ | 256 | 18 | 34 | 308 |
| [Source Files/SDL_Handler.h](/Source%20Files/SDL_Handler.h) | C++ | 22 | 156 | 14 | 192 |
| [Source Files/chess/board/board.cpp](/Source%20Files/chess/board/board.cpp) | C++ | 54 | 0 | 13 | 67 |
| [Source Files/chess/board/board.h](/Source%20Files/chess/board/board.h) | C++ | 2 | 14 | 1 | 17 |
| [Source Files/chess/board/stack.cpp](/Source%20Files/chess/board/stack.cpp) | C++ | 9 | 0 | 0 | 9 |
| [Source Files/chess/board/stack.h](/Source%20Files/chess/board/stack.h) | C++ | 2 | 0 | 0 | 2 |
| [Source Files/chess/game.cpp](/Source%20Files/chess/game.cpp) | C++ | 21 | 1 | -2 | 20 |
| [Source Files/chess/game.h](/Source%20Files/chess/game.h) | C++ | -2 | 78 | -1 | 75 |
| [Source Files/chess/gamepieces/linkedlist/Llist.cpp](/Source%20Files/chess/gamepieces/linkedlist/Llist.cpp) | C++ | 11 | 0 | 0 | 11 |
| [Source Files/chess/gamepieces/linkedlist/Llist.h](/Source%20Files/chess/gamepieces/linkedlist/Llist.h) | C++ | 4 | 0 | 0 | 4 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.cpp](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.cpp) | C++ | 48 | 0 | 0 | 48 |
| [Source Files/chess/gamepieces/pieces/bishop/bishop.h](/Source%20Files/chess/gamepieces/pieces/bishop/bishop.h) | C++ | 1 | 0 | 0 | 1 |
| [Source Files/chess/gamepieces/pieces/king/king.cpp](/Source%20Files/chess/gamepieces/pieces/king/king.cpp) | C++ | 59 | 3 | 3 | 65 |
| [Source Files/chess/gamepieces/pieces/king/king.h](/Source%20Files/chess/gamepieces/pieces/king/king.h) | C++ | 2 | 9 | 1 | 12 |
| [Source Files/chess/gamepieces/pieces/knight/knight.cpp](/Source%20Files/chess/gamepieces/pieces/knight/knight.cpp) | C++ | 36 | 0 | 0 | 36 |
| [Source Files/chess/gamepieces/pieces/knight/knight.h](/Source%20Files/chess/gamepieces/pieces/knight/knight.h) | C++ | 1 | 0 | 0 | 1 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.cpp](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.cpp) | C++ | 36 | 0 | 0 | 36 |
| [Source Files/chess/gamepieces/pieces/pawn/pawn.h](/Source%20Files/chess/gamepieces/pieces/pawn/pawn.h) | C++ | 1 | 0 | 0 | 1 |
| [Source Files/chess/gamepieces/pieces/piece.cpp](/Source%20Files/chess/gamepieces/pieces/piece.cpp) | C++ | 9 | 0 | 1 | 10 |
| [Source Files/chess/gamepieces/pieces/piece.h](/Source%20Files/chess/gamepieces/pieces/piece.h) | C++ | 8 | 8 | 1 | 17 |
| [Source Files/chess/gamepieces/pieces/queen/queen.cpp](/Source%20Files/chess/gamepieces/pieces/queen/queen.cpp) | C++ | 91 | 0 | 0 | 91 |
| [Source Files/chess/gamepieces/pieces/queen/queen.h](/Source%20Files/chess/gamepieces/pieces/queen/queen.h) | C++ | 1 | 0 | 0 | 1 |
| [Source Files/chess/gamepieces/pieces/rook/rook.cpp](/Source%20Files/chess/gamepieces/pieces/rook/rook.cpp) | C++ | 48 | 0 | 3 | 51 |
| [Source Files/chess/gamepieces/pieces/rook/rook.h](/Source%20Files/chess/gamepieces/pieces/rook/rook.h) | C++ | 1 | 0 | 0 | 1 |
| [Source Files/main.cpp](/Source%20Files/main.cpp) | C++ | 1 | 0 | 0 | 1 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details