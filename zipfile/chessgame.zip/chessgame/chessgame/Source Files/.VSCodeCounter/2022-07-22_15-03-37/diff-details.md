# Diff Details

Date : 2022-07-22 15:03:37

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 8 files,  536 codes, 73 comments, 148 blanks, all 757 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/details.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/details.md) | Markdown | 31 | 0 | 6 | 37 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/diff-details.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/diff-details.md) | Markdown | 9 | 0 | 6 | 15 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/diff.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/diff.md) | Markdown | 12 | 0 | 7 | 19 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/results.json](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/results.json) | JSON | 1 | 0 | 0 | 1 |
| [Source Files/.VSCodeCounter/2022-07-22_14-05-53/results.md](/Source%20Files/.VSCodeCounter/2022-07-22_14-05-53/results.md) | Markdown | 24 | 0 | 7 | 31 |
| [Source Files/SDL_Handler.cpp](/Source%20Files/SDL_Handler.cpp) | C++ | 383 | 47 | 96 | 526 |
| [Source Files/SDL_Handler.h](/Source%20Files/SDL_Handler.h) | C++ | 41 | 19 | 20 | 80 |
| [Source Files/main.cpp](/Source%20Files/main.cpp) | C++ | 35 | 7 | 6 | 48 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details