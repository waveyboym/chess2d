# Summary

Date : 2022-07-23 21:50:07

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 35 files,  2857 codes, 1221 comments, 586 blanks, all 4664 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 25 | 2,676 | 1,221 | 534 | 4,431 |
| Markdown | 8 | 179 | 0 | 52 | 231 |
| JSON | 2 | 2 | 0 | 0 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 35 | 2,857 | 1,221 | 586 | 4,664 |
| .VSCodeCounter | 10 | 181 | 0 | 52 | 233 |
| .VSCodeCounter\\2022-07-22_14-05-53 | 5 | 77 | 0 | 26 | 103 |
| .VSCodeCounter\\2022-07-22_15-03-37 | 5 | 104 | 0 | 26 | 130 |
| chess | 22 | 1,938 | 974 | 364 | 3,276 |
| chess\\board | 4 | 423 | 222 | 107 | 752 |
| chess\\gamepieces | 16 | 1,326 | 624 | 204 | 2,154 |
| chess\\gamepieces\\linkedlist | 2 | 119 | 82 | 38 | 239 |
| chess\\gamepieces\\pieces | 14 | 1,207 | 542 | 166 | 1,915 |
| chess\\gamepieces\\pieces\\bishop | 2 | 160 | 60 | 16 | 236 |
| chess\\gamepieces\\pieces\\king | 2 | 249 | 98 | 43 | 390 |
| chess\\gamepieces\\pieces\\knight | 2 | 147 | 68 | 15 | 230 |
| chess\\gamepieces\\pieces\\pawn | 2 | 120 | 64 | 17 | 201 |
| chess\\gamepieces\\pieces\\queen | 2 | 283 | 60 | 23 | 366 |
| chess\\gamepieces\\pieces\\rook | 2 | 160 | 52 | 20 | 232 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)