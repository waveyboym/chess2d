# Diff Summary

Date : 2022-07-22 15:03:37

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 8 files,  536 codes, 73 comments, 148 blanks, all 757 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 3 | 459 | 73 | 122 | 654 |
| Markdown | 4 | 76 | 0 | 26 | 102 |
| JSON | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 8 | 536 | 73 | 148 | 757 |
| .VSCodeCounter | 5 | 77 | 0 | 26 | 103 |
| .VSCodeCounter\\2022-07-22_14-05-53 | 5 | 77 | 0 | 26 | 103 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)