# Diff Summary

Date : 2022-07-23 21:50:07

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 30 files,  826 codes, 287 comments, 94 blanks, all 1207 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 25 | 722 | 287 | 68 | 1,077 |
| Markdown | 4 | 103 | 0 | 26 | 129 |
| JSON | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 30 | 826 | 287 | 94 | 1,207 |
| .VSCodeCounter | 5 | 104 | 0 | 26 | 130 |
| .VSCodeCounter\\2022-07-22_15-03-37 | 5 | 104 | 0 | 26 | 130 |
| chess | 22 | 443 | 113 | 20 | 576 |
| chess\\board | 4 | 67 | 14 | 14 | 95 |
| chess\\gamepieces | 16 | 357 | 20 | 9 | 386 |
| chess\\gamepieces\\linkedlist | 2 | 15 | 0 | 0 | 15 |
| chess\\gamepieces\\pieces | 14 | 342 | 20 | 9 | 371 |
| chess\\gamepieces\\pieces\\bishop | 2 | 49 | 0 | 0 | 49 |
| chess\\gamepieces\\pieces\\king | 2 | 61 | 12 | 4 | 77 |
| chess\\gamepieces\\pieces\\knight | 2 | 37 | 0 | 0 | 37 |
| chess\\gamepieces\\pieces\\pawn | 2 | 37 | 0 | 0 | 37 |
| chess\\gamepieces\\pieces\\queen | 2 | 92 | 0 | 0 | 92 |
| chess\\gamepieces\\pieces\\rook | 2 | 49 | 0 | 3 | 52 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)