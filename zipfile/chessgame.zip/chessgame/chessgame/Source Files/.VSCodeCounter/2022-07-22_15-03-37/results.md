# Summary

Date : 2022-07-22 15:03:37

Directory c:\\Users\\User\\Documents\\Modules\\career stuff\\chess2D\\chessgame\\chessgame\\Source Files

Total : 30 files,  2031 codes, 934 comments, 492 blanks, all 3457 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 25 | 1,954 | 934 | 466 | 3,354 |
| Markdown | 4 | 76 | 0 | 26 | 102 |
| JSON | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 30 | 2,031 | 934 | 492 | 3,457 |
| .VSCodeCounter | 5 | 77 | 0 | 26 | 103 |
| .VSCodeCounter\\2022-07-22_14-05-53 | 5 | 77 | 0 | 26 | 103 |
| chess | 22 | 1,495 | 861 | 344 | 2,700 |
| chess\\board | 4 | 356 | 208 | 93 | 657 |
| chess\\gamepieces | 16 | 969 | 604 | 195 | 1,768 |
| chess\\gamepieces\\linkedlist | 2 | 104 | 82 | 38 | 224 |
| chess\\gamepieces\\pieces | 14 | 865 | 522 | 157 | 1,544 |
| chess\\gamepieces\\pieces\\bishop | 2 | 111 | 60 | 16 | 187 |
| chess\\gamepieces\\pieces\\king | 2 | 188 | 86 | 39 | 313 |
| chess\\gamepieces\\pieces\\knight | 2 | 110 | 68 | 15 | 193 |
| chess\\gamepieces\\pieces\\pawn | 2 | 83 | 64 | 17 | 164 |
| chess\\gamepieces\\pieces\\queen | 2 | 191 | 60 | 23 | 274 |
| chess\\gamepieces\\pieces\\rook | 2 | 111 | 52 | 17 | 180 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)